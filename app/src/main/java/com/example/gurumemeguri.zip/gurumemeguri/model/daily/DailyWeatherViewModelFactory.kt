package com.example.gurumemeguri.model.daily

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.gurumemeguri.viewmodel.DailyWeatherViewModel

class DailyWeatherViewModelFactory(private val api: DailyWeatherApi) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return DailyWeatherViewModel(api) as T
    }
}