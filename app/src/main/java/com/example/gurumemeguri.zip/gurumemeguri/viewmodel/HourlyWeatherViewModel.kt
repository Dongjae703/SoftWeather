package com.example.gurumemeguri.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.gurumemeguri.model.hourly.HourlyWeatherApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter

class HourlyWeatherViewModel(
    private val api: HourlyWeatherApi
) : ViewModel() {

    private val _humidity = MutableStateFlow<Int?>(null)
    val humidity: StateFlow<Int?> = _humidity

    fun fetchCurrentHumidity(lat: Double, lon: Double) {
        viewModelScope.launch {
            try {
                val response = api.getHourlyWeather(lat, lon)
                val timeList = response.hourly.time
                val humidityList = response.hourly.relative_humidity_2m

                val now = LocalDateTime.now(ZoneId.of("Asia/Seoul"))
                val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:00")
                val targetTimeStr = now.format(formatter)

                val index = timeList.indexOf(targetTimeStr)
                val humidity = if (index != -1) humidityList[index] else null

                Log.d("CurrentHumidity", "현재 습도: $humidity%")
                _humidity.value = humidity

            } catch (e: Exception) {
                Log.e("HumidityVM", "에러: ${e.message}")
                _humidity.value = null
            }
        }
    }
}