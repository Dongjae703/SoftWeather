package com.example.gurumemeguri.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.gurumemeguri.model.daily.DailyPastWeatherApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class DailyPastWeatherViewModel(
    private val api: DailyPastWeatherApi
) : ViewModel() {

    private val _temperature_max = MutableStateFlow<Double?>(null)
    private val _temperature_min = MutableStateFlow<Double?>(null)
    private val _precipitation_sum = MutableStateFlow<Double?>(null)
    private val _sunrise = MutableStateFlow<String?>(null)
    private val _sunset = MutableStateFlow<String?>(null)
    private val _windspeed_max = MutableStateFlow<Double?>(null)
    private val _weatherCode = MutableStateFlow<Int?>(null)
    val temperature_max: StateFlow<Double?> = _temperature_max
    val temperature_min : StateFlow<Double?> = _temperature_min
    val precipitation_sum : StateFlow<Double?> = _precipitation_sum
    val sunrise : StateFlow<String?> = _sunrise
    val sunset : StateFlow<String?> = _sunset
    val windSpeed_max : StateFlow<Double?> = _windspeed_max
    val weatherCode : StateFlow<Int?> = _weatherCode
    fun fetchDailyWeather(lat: Double, lon: Double, targetDate:String) {
        viewModelScope.launch {
            try {
                val response = api.getDailyArchive(lat, lon, startDate = targetDate, endDate = targetDate)
                val dailyWeather = response.daily
                if(dailyWeather!=null){
                    _temperature_max.value = dailyWeather.temperature_2m_max.firstOrNull()
                    _temperature_min.value = dailyWeather.temperature_2m_min.firstOrNull()
                    _precipitation_sum.value = dailyWeather.precipitation_sum.firstOrNull()
                    _sunrise.value = dailyWeather.sunrise.firstOrNull()
                    _sunset.value = dailyWeather.sunset.firstOrNull()
                    _windspeed_max.value =dailyWeather.windspeed_10m_max.firstOrNull()
                    _weatherCode.value = dailyWeather.weathercode.firstOrNull()
                }else {
                    Log.e("WeatherVM", "currentWeather == null")
                }

            } catch (e: Exception) {
                Log.e("HumidityVM", "에러: ${e.message}")
            }
        }
    }
}