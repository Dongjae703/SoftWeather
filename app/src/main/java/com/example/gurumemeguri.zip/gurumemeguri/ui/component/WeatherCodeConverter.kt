package com.example.gurumemeguri.ui.component

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

@Composable
fun WeatherCodeConverter(weatherCode:Int?,modifier: Modifier = Modifier) {
    weatherCode?.let {
        when (it) {
            0 -> Text("맑음 (Clear sky)", style = MaterialTheme.typography.titleLarge)
            1 -> Text("거의 맑음 (Mainly clear)", style = MaterialTheme.typography.titleLarge)
            2 -> Text("부분적으로 흐림 (Partly cloudy)", style = MaterialTheme.typography.titleLarge)
            3 -> Text("흐림 (Overcast)", style = MaterialTheme.typography.titleLarge)
            45 -> Text("안개 (Fog)", style = MaterialTheme.typography.titleLarge)
            48 -> Text("서리 안개 (Depositing rime fog)", style = MaterialTheme.typography.titleLarge)
            51 -> Text("가벼운 이슬비 (Light drizzle)", style = MaterialTheme.typography.titleLarge)
            53 -> Text("중간 이슬비 (Moderate drizzle)", style = MaterialTheme.typography.titleLarge)
            55 -> Text("강한 이슬비 (Dense drizzle)", style = MaterialTheme.typography.titleLarge)
            56 -> Text("가벼운 어는 이슬비 (Light freezing drizzle)", style = MaterialTheme.typography.titleLarge)
            57 -> Text("강한 어는 이슬비 (Dense freezing drizzle)", style = MaterialTheme.typography.titleLarge)
            61 -> Text("가벼운 비 (Slight rain)", style = MaterialTheme.typography.titleLarge)
            63 -> Text("중간 비 (Moderate rain)", style = MaterialTheme.typography.titleLarge)
            65 -> Text("강한 비 (Heavy rain)", style = MaterialTheme.typography.titleLarge)
            66 -> Text("가벼운 어는 비 (Light freezing rain)", style = MaterialTheme.typography.titleLarge)
            67 -> Text("강한 어는 비 (Heavy freezing rain)", style = MaterialTheme.typography.titleLarge)
            71 -> Text("가벼운 눈 (Slight snow)", style = MaterialTheme.typography.titleLarge)
            73 -> Text("중간 눈 (Moderate snow)", style = MaterialTheme.typography.titleLarge)
            75 -> Text("강한 눈 (Heavy snow)", style = MaterialTheme.typography.titleLarge)
            77 -> Text("싸락눈 (Snow grains)", style = MaterialTheme.typography.titleLarge)
            80 -> Text("가벼운 소나기 (Slight rain showers)", style = MaterialTheme.typography.titleLarge)
            81 -> Text("중간 소나기 (Moderate rain showers)", style = MaterialTheme.typography.titleLarge)
            82 -> Text("격렬한 소나기 (Violent rain showers)", style = MaterialTheme.typography.titleLarge)
            85 -> Text("가벼운 눈 소나기 (Slight snow showers)", style = MaterialTheme.typography.titleLarge)
            86 -> Text("강한 눈 소나기 (Heavy snow showers)", style = MaterialTheme.typography.titleLarge)
            95 -> Text("천둥번개 (Thunderstorm)", style = MaterialTheme.typography.titleLarge)
            96 -> Text("천둥 + 약한 우박 (Thunderstorm with slight hail)", style = MaterialTheme.typography.titleLarge)
            99 -> Text("천둥 + 강한 우박 (Thunderstorm with heavy hail)", style = MaterialTheme.typography.titleLarge)
            else -> Text("알 수 없는 날씨 코드 ($it)", style = MaterialTheme.typography.titleLarge)
        }
    }
}