package com.example.gurumemeguri.model.daily

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.gurumemeguri.viewmodel.DailyPastWeatherViewModel

class DailyPastWeatherViewModelFactory(private val api: DailyPastWeatherApi) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return DailyPastWeatherViewModel(api) as T
    }
}