package com.example.gurumemeguri.navgraph

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.example.gurumemeguri.model.Routes
import com.example.gurumemeguri.ui.component.CitySearchScreen
import com.example.gurumemeguri.ui.component.DailyWeatherScreen
import com.example.gurumemeguri.ui.component.WeatherScreen

@Composable
fun NavGraph(navController: NavHostController) {
    NavHost(navController, startDestination = Routes.CitySearchScreen.route) {
        composable(Routes.CitySearchScreen.route) {
            CitySearchScreen(navController)
        }
        composable(
            route = Routes.WeatherScreen.route,
            arguments = listOf(
                navArgument("lat") { type = NavType.StringType },
                navArgument("lon") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val lat = backStackEntry.arguments?.getString("lat")?.toDoubleOrNull()
            val lon = backStackEntry.arguments?.getString("lon")?.toDoubleOrNull()
            if (lat != null && lon != null) {
                WeatherScreen(lat, lon, navController)
            } else {
                Text("위치 정보 오류")
            }
        }
        composable(
            route = Routes.DailyWeatherScreen.route,
            arguments = listOf(
                navArgument("lat") { type = NavType.StringType },
                navArgument("lon") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val lat = backStackEntry.arguments?.getString("lat")?.toDoubleOrNull()
            val lon = backStackEntry.arguments?.getString("lon")?.toDoubleOrNull()
            if (lat != null && lon != null) {
                DailyWeatherScreen(lat, lon)
            } else {
                Text("위치 정보 오류")
            }
        }
    }
}