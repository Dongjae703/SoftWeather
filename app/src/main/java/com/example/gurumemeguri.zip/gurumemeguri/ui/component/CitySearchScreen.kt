package com.example.gurumemeguri.ui.component

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.gurumemeguri.model.NominatimPlace
import com.example.gurumemeguri.model.RetrofitInstance
import com.example.gurumemeguri.model.Routes
import kotlinx.coroutines.launch

@Composable
fun CitySearchScreen(navController: NavController) {
    var query by remember { mutableStateOf("") }
    val searchResults = remember { mutableStateListOf<NominatimPlace>() }
    val coroutineScope = rememberCoroutineScope()

    Column(modifier = Modifier.padding(16.dp)) {
        OutlinedTextField(
            value = query,
            onValueChange = {
                query = it
                coroutineScope.launch {
                    if (query.length >= 2) {
                        val result = RetrofitInstance.nominatimApi.searchPlace(query)
                        searchResults.clear()
                        searchResults.addAll(result)
                    } else {
                        searchResults.clear()
                    }
                }
            },
            label = { Text("도시 검색") },
            modifier = Modifier.fillMaxWidth()
        )

        LazyColumn {
            items(searchResults.toList()) { place ->
                TextButton(
                    onClick = {
                        navController.navigate(
                            Routes.WeatherScreen.createRoute(place.lat, place.lon)
                        )
                    }
                ) {
                    Text("${place.display_name}\n위도: ${place.lat}, 경도: ${place.lon}")
                }
            }
        }
    }
}