package com.example.gurumemeguri.model.hourly

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.gurumemeguri.viewmodel.HourlyWeatherViewModel

class HourlyWeatherViewModelFactory(private val api: HourlyWeatherApi) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return HourlyWeatherViewModel(api) as T
    }
}